﻿

namespace CustomerApi.Common.Contants
{
    public class MessageContants
    {
        public const string NotFound = "Not found.";
        public const string UpdateFailed = "Update Failed.";
    }
}
